module RedmineIssuesTree
  VERSION = '0.0.14'
end
