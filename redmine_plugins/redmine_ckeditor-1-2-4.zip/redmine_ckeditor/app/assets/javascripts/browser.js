//= require fileuploader
//= require rich/browser/extensions
//= require rich/browser/uploader
//= require rich/browser/filebrowser
