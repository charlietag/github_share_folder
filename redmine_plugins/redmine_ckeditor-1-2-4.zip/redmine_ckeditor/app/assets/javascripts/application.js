// 
//= require rich/editor/ckeditor_path
//= require ckeditor-releases/ckeditor
//= require rich/editor/rich_editor
//= require rich/editor/rich_picker
