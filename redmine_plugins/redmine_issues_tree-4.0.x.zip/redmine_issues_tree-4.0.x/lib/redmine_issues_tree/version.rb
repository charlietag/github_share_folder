module RedmineIssuesTree
  VERSION = '0.0.13'
end
