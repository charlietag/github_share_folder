module RedmineIssuesTree
  # doomed
end